export class CreateCategoryDto {}
